package hr.tvz.programiranje.java.labos.deveti.gui;

import hr.tvz.programiranje.java.domain.Student;
import hr.tvz.programiranje.java.labos.deveti.db.DatabaseUtils;
import hr.tvz.programiranje.java.labos.deveti.main.StringUtils;

import java.awt.event.ActionEvent;
import java.util.List;

import javax.swing.JFormattedTextField;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * ActionListener klasa za gumb koji slu�i za brisanje podataka o studentima iz baze podataka.
 * 
 * @author Aleksander
 */
public class ObrisiButtonListener extends ButtonListener {

	private final JTextArea m_studentiTextArea;

	/**
	 * Konstruktor koji prima sve elemente grafi�kog su�elja koji se koriste unutar ove klase
	 * 
	 * @param p_jmbagTextField unosno polje za JMBAG studenta
	 * @param p_prezimeTextField unosno polje za prezime studenta
	 * @param p_imeTextField unosno polje za ime studenta
	 * @param p_datumRodjenjaTextField unosno polje za datum ro�enja studenta
	 * @param p_textArea tekstualno polje za ispis podataka o studentima
	 */
	public ObrisiButtonListener(final JTextField p_jmbagTextField,
			final JTextField p_prezimeTextField,
			final JTextField p_imeTextField,
			final JFormattedTextField p_datumRodjenjaTextField,
			JTextArea p_textArea) {
		super(p_jmbagTextField, p_prezimeTextField, p_imeTextField,
				p_datumRodjenjaTextField);
		m_studentiTextArea = p_textArea;
	}

	/* (non-Javadoc)
	 * @see hr.tvz.programiranje.java.labos.osmi.gui.ButtonListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if (isJMBAGUnesen()) {
			try {
				DatabaseUtils.deleteStudentByJMBAG(m_jmbagTextField.getText());

				String retci = "";

				List<Student> listaStudenata = DatabaseUtils.fetchAllStudents();

				for (Student student : listaStudenata) {
					String redak = student.getJmbag()
							+ " "
							+ student.getPrezime()
							+ " "
							+ student.getIme()
							+ " "
							+ StringUtils.DATE_FORMAT.format(student
									.getDatumRodjenja()) + "\n\r";
					retci += redak;
				}

				m_studentiTextArea.setText(retci);

			} catch (Throwable ex) {
				JOptionPane.showMessageDialog(null,
						"Do�lo je do pogre�ke kod brisanja studenta iz baze!");
			}

			JOptionPane.showMessageDialog(null,
					"Podaci o studenti su uspje�no obrisani!");
		} else {
			JOptionPane
					.showMessageDialog(null,
							"Potrebno je popuniti JMBAG studenta prije brisanja iz baze!");
		}

	}

}

package hr.tvz.programiranje.java.domain;

import java.util.Date;

/**
 * Domenska klasa koja ozna�ava entitet studenta i sadr�i sve podatke
 * koji se nalaze unutar istoimene tablice u bazi podataka.
 * 
 * @author Aleksander
 */
public class Student {
	
	private Integer m_id;
	private String m_jmbag;
	private String m_prezime;
	private String m_ime;
	private Date m_datumRodjenja;
	
	public Integer getId() {
		return m_id;
	}
	public void setId(final Integer p_id) {
		m_id = p_id;
	}
	public String getJmbag() {
		return m_jmbag;
	}
	public void setJmbag(final String p_jmbag) {
		m_jmbag = p_jmbag;
	}
	public String getPrezime() {
		return m_prezime;
	}
	public void setPrezime(final String p_prezime) {
		m_prezime = p_prezime;
	}
	public String getIme() {
		return m_ime;
	}
	public void setIme(final String p_ime) {
		m_ime = p_ime;
	}
	public Date getDatumRodjenja() {
		return m_datumRodjenja;
	}
	public void setDatumRodjenja(final Date p_datumRodjenja) {
		this.m_datumRodjenja = p_datumRodjenja;
	}

}

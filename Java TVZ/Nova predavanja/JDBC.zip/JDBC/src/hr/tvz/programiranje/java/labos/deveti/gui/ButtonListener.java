package hr.tvz.programiranje.java.labos.deveti.gui;

import hr.tvz.programiranje.java.labos.deveti.main.StringUtils;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFormattedTextField;
import javax.swing.JTextField;

/**
 * Klasa koja slu�i kao temelj za ostale ActionListener klase.
 * 
 * @author Aleksander
 */
public abstract class ButtonListener implements ActionListener {
	
	protected final JTextField m_jmbagTextField;
	protected final JTextField m_prezimeTextField;
	protected final JTextField m_imeTextField;
	protected final JFormattedTextField m_datumRodjenjaTextField;
	
	/**
	 * Konstruktor koji prima sve zajedni�ke parametre za ostale ActionListener klase.
	 * 
	 * @param p_jmbagTextField unosno polje za JMBAG studenta
	 * @param p_prezimeTextField unosno polje za prezime studenta
	 * @param p_imeTextField unosno polje za ime studenta
	 * @param p_datumRodjenjaTextField unosno polje za datum ro�enja studenta
	 */
	public ButtonListener(final JTextField p_jmbagTextField, final JTextField p_prezimeTextField,
			final JTextField p_imeTextField, final JFormattedTextField p_datumRodjenjaTextField)
	{
		m_jmbagTextField = p_jmbagTextField;
		m_prezimeTextField = p_prezimeTextField;
		m_imeTextField = p_imeTextField;
		m_datumRodjenjaTextField = p_datumRodjenjaTextField;
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public abstract void actionPerformed(ActionEvent e);
	
	/**
	 * Provjerava je li unesen podatak o JMBAG-u studenta.
	 * 
	 * @return informacija o tome je li JMBAG studenta unesen ili ne.
	 */
	protected boolean isJMBAGUnesen() {
		return StringUtils.hasText(m_jmbagTextField.getText());
	}
	
	/**
	 * Provjerava je li unesen podatak o prezimenu studenta.
	 * 
	 * @return informacija o tome je li prezime studenta uneseno ili ne.
	 */
	protected boolean isPrezimeUneseno() {
		return StringUtils.hasText(m_prezimeTextField.getText());
	}
	
	/**
	 * Provjerava je li unesen podatak o imenu studenta.
	 * 
	 * @return informacija o tome je li ime studenta uneseno ili ne.
	 */
	protected boolean isImeUneseno() {
		return StringUtils.hasText(m_imeTextField.getText());
	}
	
	/**
	 * Provjerava je li unesen podatak o datumu ro�enja studenta.
	 * 
	 * @return informacija o tome je li datum ro�enja unesen ili ne.
	 */
	protected boolean isDatumRodjenjaUneseno() {
		return StringUtils.hasText(m_datumRodjenjaTextField.getText());
	}

}

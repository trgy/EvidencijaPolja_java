package hr.tvz.programiranje.java.labos.deveti.gui;

import hr.tvz.programiranje.java.labos.deveti.main.StringUtils;

import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.text.DateFormatter;

/**
 * Predstavlja glavni okvir aplikacije.
 * 
 * @author Aleksander
 */
public class MainFrame extends JFrame {
	
	private static final long serialVersionUID = 8637372689074203613L;
	
	private final JButton dohvatiButton = new JButton("Dohvati");
	private final JButton spremiButton = new JButton("Spremi");
	private final JButton obrisiButton = new JButton("Obri�i");
	
	private final JTextField jmbagTextField = new JTextField(15);
	private final JTextField prezimeTextField = new JTextField(15);
	private final JTextField imeTextField = new JTextField(15);
	private final DateFormatter datumRodjenjaDateFormatter = new DateFormatter(StringUtils.DATE_FORMAT);
	private final JFormattedTextField datumRodjenjaTextField = new JFormattedTextField(datumRodjenjaDateFormatter);
	
	private final JTextArea studentiTextArea = new JTextArea(5, 30);
	
	/**
	 * Slu�i za kreiranje glavnog okvira aplikacije.
	 */
	public MainFrame() {
		init();
	}
	
	/**
	 * Inicijalizira glavni okvir aplikacije.
	 */
	private void init() {
		
		this.setTitle("Popis studenata");
		
		JPanel dataPanel = new JPanel();
		dataPanel.setBorder(new TitledBorder("Podaci o studentu"));
		dataPanel.setLayout(new GridBagLayout());
		
		JLabel jmbagLabel = new JLabel("JMBAG: ");
		GridBagConstraints gbc = new GridBagConstraints();
		
		gbc.gridx = 0;
		gbc.gridy = 0;
		dataPanel.add(jmbagLabel, gbc);
		
		gbc.gridx = 1;
		dataPanel.add(jmbagTextField, gbc);
		
		JLabel prezimeLabel = new JLabel("Prezime: ");
		
		gbc.gridx = 0;
		gbc.gridy = 1;
		dataPanel.add(prezimeLabel, gbc);
		
		gbc.gridx = 1;
		dataPanel.add(prezimeTextField, gbc);
		
		JLabel imeLabel = new JLabel("Ime: ");
		
		gbc.gridx = 0;
		gbc.gridy = 2;
		dataPanel.add(imeLabel, gbc);
		
		gbc.gridx = 1;
		dataPanel.add(imeTextField, gbc);
		
		JLabel datumRodjenjaLabel = new JLabel("Datum ro�enja: ");
		
		gbc.gridx = 0;
		gbc.gridy = 3;
		dataPanel.add(datumRodjenjaLabel, gbc);
		
		gbc.gridx = 1;
		datumRodjenjaTextField.setColumns(15);
		dataPanel.add(datumRodjenjaTextField, gbc);
		
		JPanel buttonPanel = new JPanel(new FlowLayout());
		buttonPanel.add(dohvatiButton);
		buttonPanel.add(spremiButton);
		buttonPanel.add(obrisiButton);
		
		gbc.gridx = 0;
		gbc.gridy = 4;
		gbc.gridwidth = 2;
		
		dataPanel.add(buttonPanel, gbc);
		
		this.getContentPane().setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));
		
		this.getContentPane().add(dataPanel);
		
		JLabel popisStudenataLabel = new JLabel("Popis svih studenata:");
		
		JPanel popisStudenataLabelPanel = new JPanel(new FlowLayout());
		popisStudenataLabelPanel.add(popisStudenataLabel);
		
		this.getContentPane().add(popisStudenataLabelPanel);
		
		JScrollPane tableScrollPane = new JScrollPane(studentiTextArea);
		
		JPanel tablePanel = new JPanel(new FlowLayout());
		tablePanel.add(tableScrollPane);
		
		this.getContentPane().add(tablePanel);
		
		DohvatiButtonListener dohvatiAction = new DohvatiButtonListener(
				jmbagTextField, prezimeTextField, imeTextField, datumRodjenjaTextField, studentiTextArea);
		
		dohvatiButton.addActionListener(dohvatiAction);
		
		SpremiButtonListener spremiAction = new SpremiButtonListener(jmbagTextField, prezimeTextField, imeTextField, datumRodjenjaTextField);
		
		spremiButton.addActionListener(spremiAction);
		
		ObrisiButtonListener obrisiAction = new ObrisiButtonListener(jmbagTextField, prezimeTextField, imeTextField, datumRodjenjaTextField, studentiTextArea);
		
		obrisiButton.addActionListener(obrisiAction);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}

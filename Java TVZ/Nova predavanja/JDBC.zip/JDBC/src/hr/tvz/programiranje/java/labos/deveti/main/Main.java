package hr.tvz.programiranje.java.labos.deveti.main;

import hr.tvz.programiranje.java.labos.deveti.gui.MainFrame;

/**
 * Slu�i za pokretanje aplikacije.
 * 
 * @author Aleksander
 */

public class Main {

	/**
	 *Kreira i prikazuje glavni okvir aplikacije.
	 * 
	 * @param args ulazni argumenti komandne linije (ne koriste se u ovoj aplikaciji)
	 */
	public static void main(String[] args) {
		MainFrame mainFrame = new MainFrame();
		mainFrame.pack();
		mainFrame.setVisible(true);
	}

}

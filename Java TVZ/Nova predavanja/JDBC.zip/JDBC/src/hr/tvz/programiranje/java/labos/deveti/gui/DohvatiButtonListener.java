package hr.tvz.programiranje.java.labos.deveti.gui;

import hr.tvz.programiranje.java.domain.Student;
import hr.tvz.programiranje.java.labos.deveti.db.DatabaseUtils;
import hr.tvz.programiranje.java.labos.deveti.main.StringUtils;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.List;

import javax.swing.JFormattedTextField;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * ActionListener klasa za gumb koji slu�i za dohva�anje studenata.
 * 
 * @author Aleksander
 */
public class DohvatiButtonListener extends ButtonListener implements ActionListener {
	
	private final JTextArea m_studentiTextArea;
	
	/**
	 * Konstruktor koji prima sve elemente grafi�kog su�elja koji se koriste unutar ove klase.
	 * 
	 * @param p_jmbagTextField unosno polje za JMBAG studenta
	 * @param p_prezimeTextField unosno polje za prezime studenta
	 * @param p_imeTextField unosno polje za ime studenta
	 * @param p_datumRodjenjaTextField unosno polje za datum ro�enja studenta
	 * @param p_textArea tekstualno polje za ispis podataka o studentima
	 */
	public DohvatiButtonListener(final JTextField p_jmbagTextField, final JTextField p_prezimeTextField,
			final JTextField p_imeTextField, final JFormattedTextField p_datumRodjenjaTextField, final JTextArea p_textArea)
	{
		super(p_jmbagTextField, p_prezimeTextField, p_imeTextField, p_datumRodjenjaTextField);
		m_studentiTextArea = p_textArea;
	}

	/* (non-Javadoc)
	 * @see hr.tvz.programiranje.java.labos.osmi.gui.ButtonListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if (isJMBAGUnesen() == false && isPrezimeUneseno() == false && isImeUneseno() == false && isDatumRodjenjaUneseno() == false) {
			
			String retci = "";
			
			try {
				List<Student> listaStudenata = DatabaseUtils.fetchAllStudents();
				
				for (Student student : listaStudenata) {
					String redak  = student.getJmbag() + " " + student.getPrezime() + " " + student.getIme() + " " + StringUtils.DATE_FORMAT.format(student.getDatumRodjenja()) + "\n\r";
					retci += redak;
				}
				
			} catch (Throwable e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(null, "Do�lo je do pogre�ke kod dohva�anja liste studenata!");
			}
			
			m_studentiTextArea.setText(retci);
		}
		else {
			
			Student searchCriteria = new Student();
			searchCriteria.setJmbag(super.m_jmbagTextField.getText());
			searchCriteria.setPrezime(m_prezimeTextField.getText());
			searchCriteria.setIme(m_imeTextField.getText());
			searchCriteria.setDatumRodjenja((Date)m_datumRodjenjaTextField.getValue());
			
			String retci = "";
			
			try {
				List<Student> listaStudenata = DatabaseUtils.fetchStudentByDefinedCriteria(searchCriteria);
				
				for (Student student : listaStudenata) {
					String redak  = student.getJmbag() + " " + student.getPrezime() + " " + student.getIme() + " " + StringUtils.DATE_FORMAT.format(student.getDatumRodjenja()) + "\n\r";
					retci += redak;
				}
				
			} catch (Throwable e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(null, "Do�lo je do pogre�ke kod dohva�anje liste studenata!");
			}
			
			m_studentiTextArea.setText(retci);
		}
	}

}

package hr.tvz.programiranje.java.labos.deveti.db;

import hr.tvz.programiranje.java.domain.Student;
import hr.tvz.programiranje.java.labos.deveti.main.StringUtils;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

/**
 * "Utility" klasa koja sadr�i sve potrebne operacije s bazom podataka. 
 * 
 * @author Aleksander
 */
public class DatabaseUtils {
	
	private static final String DATABASE_FILE = "database.properties";
	
	/**
	 * Ostvaruje vezu s bazom podataka.
	 * 
	 * @return veza s bazom podataka
	 * @throws SQLException iznimka koja se baca u slu�aju pogre�ke u komunikaciji s bazom podataka
	 * @throws IOException iznimka koja se baca u slu�aju pogre�ke u komunikaciji s "database.properties" datotekom
	 */
	private static Connection connectToDatabase() throws SQLException, IOException {
		
		Properties svojstva = new Properties();

		svojstva.load(new FileReader(DATABASE_FILE));

		String urlBazePodataka = svojstva.getProperty("bazaPodatakaUrl");
		String korisnickoIme = svojstva.getProperty("korisnickoIme");
		String lozinka = svojstva.getProperty("lozinka");
		
		Connection veza = DriverManager.getConnection(
				urlBazePodataka, korisnickoIme,lozinka);
		
		return veza;
	}
	
	/**
	 * Slu�i za zatvaranje veze s bazom podataka
	 * 
	 * @param p_connection veza s bazom podataka koju je potrebno zatvoriti
	 * @throws SQLException iznimka koja se baca u slu�aju pogre�ke u komunikaciji s bazom podataka
	 */
	private static void closeConnectionToDatabase(final Connection p_connection) throws SQLException {
		p_connection.close();
	}
	
	/**
	 * Dohva�a listu svih studenata koji se nalaze u bazi podataka.
	 * 
	 * @return lista studenata koji se nalaze u bazi podataka
	 * @throws SQLException iznimka koja se baca u slu�aju pogre�ke u komunikaciji s bazom podataka
	 * @throws IOException iznimka koja se baca u slu�aju pogre�ke u komunikaciji s "database.properties" datotekom
	*/
	public static List<Student> fetchAllStudents() throws SQLException, IOException {
		return createAndExecuteQuery(new Student());
	}
	
	/**
	 * Dohva�a listu studenata prema zadanim kriterijima.
	 * 
	 * @param p_searchCriteria zadani kriteriji za dohva�anje liste studenata iz baze podataka
	 * @return lista studenata u skladu sa zadanim kriterijima
	 * @throws SQLException iznimka koja se baca u slu�aju pogre�ke u komunikaciji s bazom podataka
	 * @throws IOException iznimka koja se baca u slu�aju pogre�ke u komunikaciji s "database.properties" datotekom
	 */
	public static List<Student> fetchStudentByDefinedCriteria(final Student p_searchCriteria) throws SQLException, IOException {
		return createAndExecuteQuery(p_searchCriteria);
	}
	
	/**
	 * Slu�i za spremanje podataka o studentu u bazu podataka.
	 * 
	 * @param p_student podaci o studenti koji se spremaju u bazu podataka
	 * @throws SQLException iznimka koja se baca u slu�aju pogre�ke u komunikaciji s bazom podataka
	 * @throws IOException iznimka koja se baca u slu�aju pogre�ke u komunikaciji s "database.properties" datotekom
	 */
	public static boolean saveStudent(final Student p_student) throws SQLException, IOException {
		Connection veza = connectToDatabase();
		
		Student noviStudent = new Student();
		
		noviStudent.setJmbag(p_student.getJmbag());
		
		List<Student> listaStudenata = fetchStudentByDefinedCriteria(noviStudent);
	
		if(listaStudenata.size() > 0) {
			//DUPLI�!!!
			return false;
		}
				
		String queryString = "INSERT INTO RAZVOJ.STUDENTI (jmbag, ime, prezime, datum_rodjenja) VALUES (?, ?, ?, ?)";
		
		PreparedStatement preparedStatement = veza.prepareStatement(queryString);
		preparedStatement.setString(1, p_student.getJmbag());
		preparedStatement.setString(2, p_student.getIme());
		preparedStatement.setString(3, p_student.getPrezime());
		java.sql.Date datum = convertToSQLDate(p_student.getDatumRodjenja());
		preparedStatement.setDate(4, datum);
		
		preparedStatement.executeUpdate();
		
		closeConnectionToDatabase(veza);
		
		return true;
	}
	
	/**
	 * Slu�i za brisanje podataka o studentu iz baze podataka.
	 * 
	 * @param p_jmbag JMBAG studenta koji se �eli izbrisati iz baze podataka
	 * @throws SQLException iznimka koja se baca u slu�aju pogre�ke u komunikaciji s bazom podataka
	 * @throws IOException iznimka koja se baca u slu�aju pogre�ke u komunikaciji s "database.properties" datotekom
	 */
	public static void deleteStudentByJMBAG(final String p_jmbag) throws SQLException, IOException {
		Connection veza = connectToDatabase();
		
		String queryString = "DELETE FROM RAZVOJ.STUDENTI WHERE jmbag = ?";
		
		PreparedStatement preparedStatement = veza.prepareStatement(queryString);
		preparedStatement.setString(1, p_jmbag);
		
		preparedStatement.executeUpdate();
		
		closeConnectionToDatabase(veza);
	}
	
	/**
	 * Slu�i za dohva�anje svih redaka iz tablice "STUDENTI" koji odgovaraju zadanim kriterijima.
	 * 
	 * @param p_searchCriteria zadani kriteriji za pretra�ivanje baze podataka o studentima
	 * @return lista studenata prema zadanim kriterijima
	 * @throws SQLException iznimka koja se baca u slu�aju pogre�ke u komunikaciji s bazom podataka
	 * @throws IOException iznimka koja se baca u slu�aju pogre�ke u komunikaciji s "database.properties" datotekom
	
	 */
	private static List<Student> createAndExecuteQuery(final Student p_searchCriteria) throws SQLException, IOException {
		
		Connection veza = connectToDatabase();
		
		String queryString = "SELECT * FROM RAZVOJ.STUDENTI WHERE 1=1 ";
		
		if (StringUtils.hasText(p_searchCriteria.getJmbag())) {
			queryString += " AND jmbag = ?";
		}
		
		if (StringUtils.hasText(p_searchCriteria.getPrezime())) {
			queryString += " AND prezime = ?";
		}
		
		if (StringUtils.hasText(p_searchCriteria.getIme())) {
			queryString += " AND ime = ?";
		}
		
		if (p_searchCriteria.getDatumRodjenja() != null) {
			queryString += " AND datum_rodjenja = ?";
		}
		
		PreparedStatement preparedStatement = veza.prepareStatement(queryString);
		int parameterNumber = 1;
		
		if (StringUtils.hasText(p_searchCriteria.getJmbag())) {
			preparedStatement.setString(parameterNumber, p_searchCriteria.getJmbag());
			parameterNumber++;
		}
		
		if (StringUtils.hasText(p_searchCriteria.getPrezime())) {
			preparedStatement.setString(parameterNumber, p_searchCriteria.getPrezime());
			parameterNumber++;
		}
		
		if (StringUtils.hasText(p_searchCriteria.getIme())) {
			preparedStatement.setString(parameterNumber, p_searchCriteria.getIme());
			parameterNumber++;
		}
		
		if (p_searchCriteria.getDatumRodjenja() != null) {
			java.sql.Date datum = convertToSQLDate(p_searchCriteria.getDatumRodjenja());
			preparedStatement.setDate(parameterNumber, datum);
		}
		
		ResultSet rs = preparedStatement.executeQuery();
		
		List<Student> listaStudenata = new ArrayList<Student>();

		while (rs.next()) {
			int id = rs.getInt("id");
			String jmbag = rs.getString("jmbag");
			String ime = rs.getString("ime");
			String prezime = rs.getString("prezime");
			Date datumRodjenja = rs.getDate("datum_rodjenja");

			Student noviStudent = new Student();
			noviStudent.setId(id);
			noviStudent.setJmbag(jmbag);
			noviStudent.setPrezime(prezime);
			noviStudent.setIme(ime);
			noviStudent.setDatumRodjenja(datumRodjenja);
			
			listaStudenata.add(noviStudent);
		}
		
		closeConnectionToDatabase(veza);
		
		return listaStudenata;
	}
	
	/**
	 * Slu�i za pretvorbu jednog formata datuma (java.util.Date) u drugi (java.sql.Date).
	 * 
	 * @param p_date datum koji je potrebno pretvoriti u drugi oblik
	 * @return pretvoreni oblik datuma
	 */
	private static java.sql.Date convertToSQLDate(final Date p_date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(p_date);
		java.sql.Date datum = new java.sql.Date(calendar.getTimeInMillis());
		return datum;
	}

}

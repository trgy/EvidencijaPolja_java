package hr.tvz.programiranje.java.labos.deveti.gui;

import hr.tvz.programiranje.java.domain.Student;
import hr.tvz.programiranje.java.labos.deveti.db.DatabaseUtils;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

import javax.swing.JFormattedTextField;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 * ActionListener klasa za gumb koji slu�i za spremanje podataka o novim studentima u bazu podataka.
 * 
 * @author Aleksander
 */
public class SpremiButtonListener extends ButtonListener implements ActionListener {
	
	/**
	 * Konstruktor koji prima sve elemente grafi�kog su�elja koji se koriste unutar ove klase
	 * 
	 * @param p_jmbagTextField unosno polje za JMBAG studenta
	 * @param p_prezimeTextField unosno polje za prezime studenta
	 * @param p_imeTextField unosno polje za ime studenta
	 * @param p_datumRodjenjaTextField unosno polje za datum ro�enja studenta
	 */
	public SpremiButtonListener(final JTextField p_jmbagTextField, final JTextField p_prezimeTextField,
			final JTextField p_imeTextField, final JFormattedTextField p_datumRodjenjaTextField) {
		super(p_jmbagTextField, p_prezimeTextField, p_imeTextField, p_datumRodjenjaTextField);
	}

	/* (non-Javadoc)
	 * @see hr.tvz.programiranje.java.labos.osmi.gui.ButtonListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if (isJMBAGUnesen() && isPrezimeUneseno() && isImeUneseno() && isDatumRodjenjaUneseno()) {
			
			Student student = new Student();
			student.setJmbag(m_jmbagTextField.getText());
			student.setPrezime(m_prezimeTextField.getText());
			student.setIme(m_imeTextField.getText());
			student.setDatumRodjenja((Date) m_datumRodjenjaTextField.getValue());
			
			try {
				if(DatabaseUtils.saveStudent(student) == false) {
					JOptionPane.showMessageDialog(null, "Taj JMBAG ve� postoji!");
				}
				else {
					JOptionPane.showMessageDialog(null, "Podaci o studenti su uspje�no spremljeni!");
				}
			} catch (Throwable e) {
				JOptionPane.showMessageDialog(null, "Do�lo je do pogre�ke kod spremanja studenta u bazu!");
			}
			
			
		}
		else {
			JOptionPane.showMessageDialog(null, "Potrebno je popuniti sve podatke o studentu prije spremanja u bazu!");
		}

	}

}

package hr.tvz.programiranje.java.labos.deveti.main;

import java.text.SimpleDateFormat;

/**
 * Sadr�i "utility" metode koje se �esto koriste unutar aplikacije.
 * 
 * @author Aleksander
 */
public class StringUtils {
	
	public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd.MM.yyyy.");

	/**
	 * Provjerava je li neki String objekt popunjen ili ne. Popunjen String objekt je onaj objekt
	 * koji nema "null" referencu i nije jednak praznom Stringu: "".
	 * 
	 * @param p_text String objekt koji se provjerava 
	 * @return informacija o tome je li neki String objekt popunjen ili ne.
	 */
	public static final boolean hasText(final String p_text) {
		if (p_text == null || "".equals(p_text)) {
			return false;
		}
		else {
			return true;
		}
	}
	
}
